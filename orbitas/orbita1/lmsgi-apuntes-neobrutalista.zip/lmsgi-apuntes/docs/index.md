---
hide:
  - navigation
  - toc
---

# Lenguajes de Marcas

![Portada Lenguajes de Marcas](assets/referencias.jpg)

# ¡Bienvenidos al módulo de **Lenguajes de Marcas y Sistemas de Gestión de la Información** del ciclo de **Desarrollo de Aplicaciones Web**!

Este curso está diseñado para que adquieras las habilidades necesarias en el manejo de lenguajes de marcas y sistemas de gestión de información, los cuales son fundamentales en el desarrollo de aplicaciones web modernas. A lo largo del módulo, aprenderás cómo estructurar, transmitir y presentar información utilizando tecnologías clave como **HTML, CSS, JSON**, y **JavaScript**.

## Tabla de contenido

### Introducción

* [Unidad 1: Introducción a los lenguajes de marcas](apuntes/ud1.md)

### HTML y CSS

* [Unidad 2: HTML5](apuntes/ud2-1.md)
* [Unidad 3: CSS3](apuntes/ud3.md)

### JavaScript (DOM y eventos)

* [Unidad 4: Introducción a JavaScript](apuntes/ud4.md)
* [Unidad 4.1: Manipulación del DOM y eventos](apuntes/ud4-1.md)

### XML, JSON y asincronía

* [Unidad 5: Definición de esquemas y vocabularios](apuntes/ud5.md)
* [Unidad 5.1: JSON Schema y herramientas de validación](apuntes/ud5-1.md)
* [Unidad 5.2: Callbacks y asincronía en JavaScript](apuntes/ud5-2.md)
* [Unidad 5.3: Fetch y APIs](apuntes/ud5-3.md)
* [Unidad 5.4: Persistencia, caché y almacenamiento en la nube](apuntes/ud5-4.md)
* [Unidad 5.5: Transformación de documentos con JavaScript](apuntes/ud5-5.md)

### Proyectos

* [Proyecto 1: Desarrollo de una aplicación web](proyectos/proyecto1.md)
* [Proyecto 2: Funcionalidades interactivas con JavaScript](proyectos/proyecto2.md)
* [Proyecto 2 · Recuperación del Proyecto 1](proyectos/proyecto2-recuperacion.md)
* [Proyecto 3: Asincronía](proyectos/proyecto3.md)

## Referencias web generales

El desarrollo de software está en constante evolución, actualmente podemos observar como una avalancha de nuevas tendencias tecnológicas y metodologías se va abriendo paso. Este es el motivo principal por el que la mayor parte de los apuntes proporcionados no son más que referencias web actuales a los temas que vamos a tratar.

* [HTML5 by Manz](https://lenguajehtml.com/html/)
* [SVG by Manz](https://lenguajehtml.com/svg/)
* [CSS by Manz](https://lenguajecss.com/css/)
* [Javascript by Manz](https://lenguajejs.com/javascript/)
* [DOM by Manz](https://lenguajejs.com/dom/)
* [FreeCodeCamp](https://www.freecodecamp.org/)
* [developer.mozilla.org](https://developer.mozilla.org/es/docs/Web/JavaScript)
* [The Modern JavaScript Tutorial](https://javascript.info/)
* [Javascript Cheatsheet](assets/javascript-cheatsheet.pdf)
* [Javascript notes by Majo Ledesma](assets/js-notesByMajoLedesma.pdf)

## ¿Qué vas a aprender?

### 1. Lenguajes de Marcas
Estudiarás las características fundamentales de los **lenguajes de marcas** como **HTML** y **XML**, los cuales permiten estructurar y almacenar información de manera eficiente. Te familiarizarás con las diferentes versiones de estos lenguajes y cómo aplicarlos en contextos reales, analizando la estructura de documentos y comprendiendo las ventajas que ofrecen en el manejo de la información.

### 2. Creación de Documentos Web
Aquí te sumergirás en la construcción de páginas web utilizando **HTML5** para la estructura y **CSS** para la presentación. Aprenderás a aplicar hojas de estilo que mejoren la apariencia de los sitios web, optimizando su diseño para diferentes dispositivos y validando tanto el código HTML como las hojas de estilo para cumplir con los estándares de la web.

### 3. Programación con JavaScript
Verás cómo **JavaScript** te permite interactuar con las páginas web, manipulando el DOM (Document Object Model) para cambiar dinámicamente el contenido, el estilo y la estructura de los documentos. Aprenderás a seleccionar, modificar y eliminar elementos de una página web, así como a hacer que estos cambios sean reactivos e interactivos.

### 4. Validación de Documentos con JSON
Uno de los formatos más populares para el intercambio de datos en la web es **JSON (JavaScript Object Notation)**. Aprenderás a:

- **Describir y estructurar la información** en formato JSON, utilizando objetos, arrays y pares clave-valor.
- **Validar documentos JSON** mediante el uso de herramientas como **JSON Schema**, que te permitirán asegurar que los datos recibidos cumplen con las reglas de estructura y tipos requeridos.
- Aplicar JSON en **APIs web**, entendiendo cómo se utiliza para transmitir información entre servidores y clientes en aplicaciones modernas.

### 5. Hojas de Estilo CSS
Además de aprender a estructurar páginas web con HTML, verás cómo **CSS** te permite mejorar la presentación visual de estas páginas. Aprenderás a aplicar estilos a los elementos HTML, a crear diseños responsivos que se adapten a distintos dispositivos y a utilizar las últimas características de **CSS3** para animaciones, transiciones y otros efectos visuales avanzados.

## ¿Por qué es importante?

El manejo adecuado de estos lenguajes es esencial para el desarrollo web profesional. Aprenderás no solo a crear páginas web estéticamente atractivas, sino también a garantizar que la información que manejen sea clara, accesible y bien estructurada. Estas habilidades son clave para el desarrollo de aplicaciones modernas que interactúan con datos y ofrecen experiencias dinámicas y personalizadas para los usuarios.

## Herramientas que usarás

- **HTML5 y CSS3**: para estructurar y dar estilo a las páginas web.
- **JavaScript**: para hacer que las páginas sean dinámicas e interactivas.
- **JSON**: para el intercambio y validación de datos entre aplicaciones.
- **JSON Schema**: para garantizar que los datos cumplan con una estructura determinada.

Al finalizar este curso, estarás preparado para desarrollar aplicaciones web modernas que gestionen y presenten información de forma eficaz, aplicando las mejores prácticas de desarrollo y diseño web.
